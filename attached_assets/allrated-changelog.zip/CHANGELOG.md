# Allrated — Change Log

## Session: July 5, 2026

---

### 1. Project Setup & Migration
- **Replaced AI Studio single-file app** with the full-stack hybrid monorepo (`client/` + `server/`)
- Configured Replit's built-in PostgreSQL via Prisma
- Ran migrations (`prisma migrate dev --name init`) — schema applied to `heliumdb`
- Seeded 63 titles, 10 platforms, and admin account via `npm run db:seed`
- Admin password updated to the value of `ADMIN_PASSWORD` secret (old hardcoded `admin123` removed)

---

### 2. New Server Routes

#### `server/src/routes/netmirror.ts` *(new file)*
- `GET /api/netmirror` — proxies NetMirror home endpoint; requires JWT auth + `NETMIRROR_API_KEY`
- `GET /api/netmirror/stream?id=` — proxies NetMirror stream link lookup; requires JWT auth
- Auto-selects base URL: `screenscapeapi.dev` for `sk_` keys, `netmirror.one` otherwise

#### `server/src/routes/showbox.ts` *(new file)*
- `GET /api/showbox/link?type=&id=[&season=&episode=]` — fetches Febbox download links
- Requires JWT auth; uses `SHOWBOX_FEB_BOX_API_URL` + `FEB_BOX_TOKEN` secrets
- Returns 503 gracefully if URL not configured

#### `server/src/routes/config.ts` *(new file)*
- `GET /api/config` — public endpoint returning client-safe config
- Serves `supabaseUrl`, `supabaseAnonKey`, `aceternityApiKey` from server env to the frontend

---

### 3. Server Entry Point — `server/src/server.ts` *(modified)*
- Registered three new route namespaces: `/api/netmirror`, `/api/showbox`, `/api/config`
- Fixed default `CLIENT_URL` from `localhost:5173` → `localhost:5000`
- Added `export default app` so the server works as a Vercel serverless function
- `app.listen()` now only runs when `process.env.VERCEL` is not set

---

### 4. Prisma Schema — `server/prisma/schema.prisma` *(modified)*
- Added `binaryTargets = ["native", "rhel-openssl-1.0.x"]` for Vercel serverless compatibility

---

### 5. Seed Script — `server/prisma/seed.ts` *(modified)*
- Removed hardcoded `admin123` password
- Now reads `ADMIN_PASSWORD` from environment; exits with error if not set
- `ADMIN_EMAIL` is also configurable (defaults to `admin@allrated.local`)

---

### 6. Client — Supabase Integration

#### `client/src/lib/supabase.ts` *(new file)*
- Exports `getSupabase(): Promise<SupabaseClient | null>`
- Lazy-initialises a Supabase client by fetching config from `/api/config`
- Returns `null` gracefully if Supabase is not configured
- Singleton — safe to call multiple times

#### `client/package.json` *(modified)*
- Added `@supabase/supabase-js` dependency

---

### 7. Client Build Fix — `client/src/lib/auth.ts` → `auth.tsx` *(renamed)*
- File contained JSX (`<AuthContext.Provider>`) but had a `.ts` extension
- esbuild rejected it at startup — renamed to `.tsx` to fix the build

---

### 8. Vite Config — `client/vite.config.ts` *(modified)*
- Changed dev server port from `5173` → `5000` (Replit webview requirement)
- Added `allowedHosts: true as const` (Replit proxy compatibility)
- Updated API proxy target from `localhost:4000` → `localhost:3000`

---

### 9. Vercel Deployment

#### `vercel.json` *(new file)*
```json
{
  "version": 2,
  "buildCommand": "cd server && npm install && npx prisma generate && cd ../client && npm install && npm run build",
  "outputDirectory": "client/dist",
  "functions": {
    "api/index.ts": { "maxDuration": 30, "includeFiles": "server/**" }
  },
  "rewrites": [
    { "source": "/api/:path*", "destination": "/api/index" },
    { "source": "/((?!api/).*)", "destination": "/index.html" }
  ]
}
```

#### `api/index.ts` *(new file)*
- Thin serverless adapter: imports Express `app` and re-exports it as the Vercel handler

---

### 10. Secrets Configured

| Secret | Status |
|---|---|
| `GEMINI_API_KEY` | ✅ Set |
| `JWT_SECRET` | ✅ Set |
| `TMDB_API_KEY` | ✅ Set |
| `FEB_BOX_TOKEN` | ✅ Set |
| `SHOWBOX_FEB_BOX_API_URL` | ✅ Set |
| `ACETERNITY_API_KEY` | ✅ Set |
| `SUPABASE_URL` | ✅ Set |
| `SUPABASE_ANON_KEY` | ✅ Set |
| `ADMIN_PASSWORD` | ✅ Set |
| `NETMIRROR_API_KEY` | ⏳ Not yet provided |

---

### 11. Workflows

| Workflow | Command | Port | Type |
|---|---|---|---|
| API Server | `cd server && npm run dev` | 3000 | console |
| Start application | `cd client && npm run dev` | 5000 | webview |

---

### Pre-Vercel Checklist
- [ ] Provision external PostgreSQL (Neon / Supabase Postgres / Railway) — Replit's DB is not reachable from Vercel
- [ ] Add all secrets to Vercel Environment Variables
- [ ] Update `CLIENT_URL` in Vercel env to your production domain (for CORS)
- [ ] Add `NETMIRROR_API_KEY` when available

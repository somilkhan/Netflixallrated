# AI Agent Loop Instructions — Allrated

> Read this FIRST before touching any code. Follow these steps in order. Do NOT skip steps.

---

## STEP 0: Before You Start

```bash
# Verify your environment
node --version  # Should be 18+
npm --version   # Should be 9+
```

---

## STEP 1: Server Setup & Verify

```bash
cd server
cp .env.example .env
# Edit .env — set DATABASE_URL to your PostgreSQL connection string
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run db:seed
npm run dev
```

**Verify:** `curl http://localhost:4000/api/health` should return `{"status":"ok"}`

---

## STEP 2: Client Setup & Verify

```bash
cd client
npm install
npm run dev
```

**Verify:** Open http://localhost:5173 — you should see the dark cinematic UI with movie cards.

---

## STEP 3: The Loop — Fix → Lint → Test → Commit

For EVERY change you make, follow this loop:

### 3.1 Make the change
### 3.2 Run TypeScript check (NO SKIP)

```bash
# In /server
npx tsc --noEmit

# In /client
npx tsc --noEmit
```

**If errors:** Fix them ALL before proceeding. NO `// @ts-ignore` without explicit approval.

### 3.3 Run ESLint (if configured) or manual review

Check for:
- Unused imports/variables
- Missing return types on functions
- `any` types — replace with proper types
- Missing `key` props in React lists
- Accessibility issues (`alt`, `aria-label`, etc.)

### 3.4 Test the feature manually

Click through EVERY affected page. Check browser console for:
- Red errors
- Failed API calls (Network tab)
- React warnings (StrictMode)

### 3.5 Run backend API tests with curl

```bash
# Test auth
curl -X POST http://localhost:4000/api/auth/register   -H "Content-Type: application/json"   -d '{"email":"test@test.com","password":"123456","displayName":"Test"}'

# Test login
curl -X POST http://localhost:4000/api/auth/login   -H "Content-Type: application/json"   -d '{"email":"test@test.com","password":"123456"}'

# Test titles list
curl http://localhost:4000/api/titles

# Test with auth (replace TOKEN)
curl http://localhost:4000/api/auth/me   -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

### 3.6 If ANY error → Go back to 3.1

Do NOT proceed to next feature until current one is 100% clean.

---

## STEP 4: Common Fixes Checklist

| Issue | Fix |
|-------|-----|
| `Property 'X' does not exist on type 'Y'` | Add proper interface/type definition |
| `Cannot find module` | Check import path, run `npm install` |
| `React Hook useEffect has missing dependency` | Add dependency to array or use `useRef` |
| `Expression produces a union type that is too complex` | Explicitly type the variable |
| Prisma type errors | Run `npx prisma generate` after schema changes |
| CORS errors | Check `CLIENT_URL` in server `.env` matches client port |
| JWT errors | Verify `JWT_SECRET` is set and not empty |

---

## STEP 5: Before Final Delivery

- [ ] `npx tsc --noEmit` passes in BOTH server/ and client/
- [ ] No console errors in browser
- [ ] All API endpoints respond correctly
- [ ] Auth flow works end-to-end (register → login → protected route)
- [ ] Watchlist add/remove/update works
- [ ] Rating submit + display works
- [ ] Search with filters works
- [ ] Admin panel can add titles
- [ ] Mobile bottom nav works
- [ ] Reduced motion respected (`prefers-reduced-motion`)

---

## CRITICAL RULES

1. **NO `any` types** — define interfaces in a `types.ts` file if needed
2. **NO skipped error handling** — every `fetch`/`prisma` call needs try/catch or `.catch()`
3. **NO mock data in final build** — everything must hit real API
4. **NO hardcoded secrets** — use `.env` for JWT_SECRET, DB_URL, etc.
5. **NO unlicensed video embeds** — only official YouTube trailers or self-hosted

---

## ENV VARIABLES NEEDED

### server/.env
```
DATABASE_URL="postgresql://user:pass@localhost:5432/allrated"
JWT_SECRET="minimum-32-characters-long-secret-key-here"
PORT=4000
CLIENT_URL="http://localhost:5173"
TMDB_API_KEY="your-tmdb-api-key"
TMDB_API_BASE="https://api.themoviedb.org/3"
TMDB_IMAGE_BASE="https://image.tmdb.org/t/p"
```

## HYBRID BACKEND — DO NOT REVERT THESE

This app uses TMDB only for catalog metadata (search/import). Ratings, watchlist,
and auth stay in our own Prisma/Postgres DB — never move those to a third-party
service. Do not change the design system (maroon #7A2530 / amber #C99A4A / void
#0B0908 palette, Fraunces + IBM Plex Mono fonts, the 4-tier Skip/Timepass/Go for
it/Perfection rating system) unless explicitly asked. If you regenerate a file,
diff it against git before committing to make sure none of the above got lost.

Since the schema changed (added `Role` enum + `User.role`, and `Title.tmdbId` /
`posterUrl` / `backdropUrl`), run `npx prisma migrate dev --name hybrid-backend`
after pulling these changes, then `npm run db:seed` again to get the admin login.

### client/.env
```
VITE_API_URL="http://localhost:4000/api"
```

---

## DEPLOYMENT

- **Frontend:** Vercel — `cd client && vercel --prod`
- **Backend:** Railway/Render — `cd server && railway up`
- **Database:** Railway PostgreSQL or Supabase

Remember to set production env vars in both platforms.

---

## GOT STUCK?

1. Check this file again — you probably skipped a step
2. Run `npx tsc --noEmit` and read the FIRST error only
3. Fix that one error, re-run, repeat
4. If still stuck — paste the EXACT error message + file path

---

**Now start from STEP 1. Do not deviate.**
